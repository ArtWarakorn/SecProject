/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bmoneysystem;

import javax.swing.JOptionPane;

/**
 *
 * @author warak
 */
public class CFineAccount {
    
    String an = "";
    String sql;
    
    public CFineAccount(String acNum){
        an = acNum;
    }
    
    String name = "";
    String money = "";
    String txt = "Account Found";
    
    public String findAccount() {
        try {
            
            sql = "SELECT * FROM bankdb.bank WHERE AccountNumber='" + an + "'";
            
            CGetConnect cg = new CGetConnect();
            cg.getConnect();
            cg.getStatmant();
            cg.getResult(sql);

            if(cg.rs.next()) { 
                name = cg.rs.getString("Name");
                money = cg.rs.getString("money");      
            }
            else{
                txt = "Account not found";
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return txt;
    }
}
