/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bmoneysystem;
import java.sql.*;
/**
 *
 * @author warak
 */
public class CGetConnect {
    
    String url = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String urlfn = "com.mysql.cj.jdbc.Driver";
    String user = "root";
    String password = "2549Art2549";
    
    Connection con;
    Statement st;
    ResultSet rs;
    
    public void getConnect() {
        
        try {
            
            Class.forName(urlfn);
            con = DriverManager.getConnection(url, user, password);
            
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public void getStatmant() {
        
        try {  
            st = con.createStatement();
        }
        
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ResultSet getResult(String sql) {
        try {
            rs = st.executeQuery(sql);   
        }
        
        catch (Exception e) {
            e.printStackTrace();
        }
        
        return rs;
    }
}
